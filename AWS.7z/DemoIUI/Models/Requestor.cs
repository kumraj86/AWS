﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web;


namespace DemoIUI.Models
{
    public static class Requestor
    {
        internal static ServiceResult<object> GetRequestor(string url)
        {
            dynamic strResponse = "";
            using (var client = new HttpClient())
            {
                var responseTask = client.GetAsync(url);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    //var readTask = result.Content.ReadAsAsync<dynamic>();
                    //readTask.Wait();
                    //strResponse = readTask.Result;
                    strResponse = result.Content.ReadAsStringAsync().Result;
                }
            }
            ServiceResult<object> d = JsonConvert.DeserializeObject<ServiceResult<object>>(strResponse.ToString());
            return d;
        }


        internal static string GetRequestors(string url)
        {
            dynamic strResponse = "";
            using (var client = new HttpClient())
            {
                var responseTask = client.GetAsync(url);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    //var readTask = result.Content.ReadAsAsync<dynamic>();
                    //readTask.Wait();
                    //strResponse = readTask.Result;
                    strResponse = result.Content.ReadAsStringAsync().Result;
                }
            }

            return strResponse;
        }

        internal static ServiceResult<object> PostRequestor<T>(string url, T val)
        {
            dynamic strResponse = "";
            using (var client = new HttpClient())
            {
                var postTask = client.PostAsJsonAsync<dynamic>(url, val);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<dynamic>();
                    readTask.Wait();
                    strResponse = readTask.Result;
                }
                else
                {
                    strResponse = "Error In Post Response";
                }
            }
            ServiceResult<object> d = JsonConvert.DeserializeObject<ServiceResult<object>>(strResponse.ToString());
            return d;
        }
       

        internal static string PostRequestors<T>(string url, T val)
        {
            dynamic strResponse = "";

            using (var client = new HttpClient())
            {
                var postTask = client.PostAsJsonAsync<dynamic>(url, val);

                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<dynamic>();
                    readTask.Wait();
                    strResponse = readTask.Result;
                }
                else
                {
                    strResponse = "Error In Post Response";
                }
            }
            //ServiceResult<object> d = JsonConvert.DeserializeObject<ServiceResult<object>>(strResponse.ToString());
            return strResponse.ToString();
        }
    }

    public class ServiceStatus
    {
        public int SuccessCode
        {
            get;
            set;
        }


        public string Message
        {
            get;
            set;
        }

        public ServiceStatus()
        {
            SuccessCode = 0;
            Message = "Service Call failed";
        }
    }

    public class ServiceResult<T>
    {
        public ServiceStatus Status
        {
            get;
            set;
        }



        public ServiceResult()
        {
            Status = new ServiceStatus();
        }




        public T Result
        {
            get;
            set;
        }
    }

}
