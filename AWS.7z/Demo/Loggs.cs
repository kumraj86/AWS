﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demo
{
    public class Loggs
    {
        public string logMessage { get; set; }

        public string logPath { get; set; }

        public string S3Key { get; set; }

        public IFormFile FileToUpload { get; set; }

        public bool IsTextFileOnly { get; set; }
    }

    public class FileList
    {
        public string FileName { get; set; }
        public int FileId{ get; set; }
    }
}
