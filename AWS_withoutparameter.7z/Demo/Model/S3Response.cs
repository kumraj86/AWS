﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Amazon.S3;
using System.IO;

namespace Demo.Model
{
    public class S3Response
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }

        public byte[] response1 { get; set; }


        public Microsoft.AspNetCore.Mvc.FileContentResult files { get; set; }

      

    }
}
