﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Amazon.S3.Util;
using Amazon;
using Amazon.KeyManagementService;
using Amazon.S3.Encryption;
using Demo.Model;



namespace Demo.Services
{
    public class S3Service : IS3Service
    {
      
        private  string BUCKET_NAME = Startup.bucketname;
        public async Task<S3Response> NE_GetObjectFromAmazons3(string S3_KEY)
        {
            S3Response oS3Response = new S3Response();
            oS3Response.StatusCode = 0;
            string responsebody = "";
            try
            {
                AmazonS3Client _client = new AmazonS3Client();
                var request = new GetObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    Key = S3_KEY
                };
                using (var response = await _client.GetObjectAsync(request))
                using (var responseStream = response.ResponseStream)
                using (var reader = new StreamReader(responseStream))
                {
                    //responsebody = reader.ReadToEnd();
                    while (!reader.EndOfStream)
                    {
                        responsebody += reader.ReadLine();                        
                    }

                }
            }
            catch (Exception ex)
            {
                oS3Response.StatusCode = 1;
                responsebody = "Error during reading file";
            }
          
           
            oS3Response.Message = responsebody;
            return oS3Response;
        }

        public async Task<S3Response> NE_WriteContentObjectInAmazons3(string S3_KEY, string logs)
        {
            string responsebody = "";
            string readresponsebody = "";
            S3Response oS3Response = new S3Response();
            oS3Response.StatusCode = 0;
            AmazonS3Client _client = new AmazonS3Client();
            try
            {
                var request = new GetObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    Key = S3_KEY
                };
                using (var response = await _client.GetObjectAsync(request))
                using (var responseStream = response.ResponseStream)
                using (var reader = new StreamReader(responseStream))
                {
                    readresponsebody = reader.ReadToEnd();
                }

                var request1 = new PutObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    Key = S3_KEY,
                    ContentBody = readresponsebody + "<br>" + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss.fff tt", System.Globalization.CultureInfo.CurrentCulture) + " " + logs

                };
                // ContentBody = readresponsebody + "\n" + logs
                ////DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss.fff tt", System.Globalization.CultureInfo.CurrentCulture) + " " +
                await _client.PutObjectAsync(request1);
                responsebody = "Add record is succesfully";
            }
            catch (Exception ex)
            {
                oS3Response.StatusCode = 1;
                responsebody = "Error during writing in file";
            }
           
            oS3Response.Message = responsebody;
            return oS3Response;
        }

        public async Task<List<FileList>> ListingObjectsAsync(bool IsTextFileOnly)
        {
            string responsebody = "";
            List<FileList> fileList = new List<FileList>();
            AmazonS3Client _client = new AmazonS3Client();
            try
            {
                ListObjectsV2Request request = new ListObjectsV2Request
                {
                    BucketName = BUCKET_NAME,
                    MaxKeys = 10
                };
                ListObjectsV2Response response;
                do
                {
                    response = await _client.ListObjectsV2Async(request);
                    // Process the response.
                    int k = 1;
                    foreach (S3Object entry in response.S3Objects)
                    {
                        if (IsTextFileOnly == true)
                        {
                            if (entry.Key.Contains(".txt"))
                            {
                                FileList objFileList = new FileList();
                                objFileList.FileId = k;
                                objFileList.FileName = entry.Key;
                                fileList.Add(objFileList);
                                k++;
                            }
                        }
                        else
                        {
                            FileList objFileList = new FileList();
                            objFileList.FileId = k;
                            objFileList.FileName = entry.Key;
                            fileList.Add(objFileList);
                            k++;

                        }
                    }
                    request.ContinuationToken = response.NextContinuationToken;
                } while (response.IsTruncated);

            }
            catch (AmazonS3Exception amazonS3Exception)
            {
                Console.WriteLine("S3 error occurred. Exception: " + amazonS3Exception.ToString());
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.ToString());
                Console.ReadKey();
            }
            return fileList;
        }

        public async Task<S3Response> NE_ReadS3Data(string S3_KEY)
        {
            S3Response oS3Response = new S3Response();
            oS3Response.StatusCode = 0;
            string responsebody = "";
            try
            {
                AmazonS3Client _client = new AmazonS3Client();
                var request = new GetObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    Key = S3_KEY
                };
                using (var response = await _client.GetObjectAsync(request))
                using (var responseStream = response.ResponseStream)
                using (var reader = new StreamReader(responseStream))
                {
                    oS3Response.response1 = System.Text.Encoding.Default.GetBytes(reader.ReadToEnd());
                }
            }
            catch (Exception ex)
            {
                oS3Response.StatusCode = 1;
                responsebody = "Error during reading file";
            }
            oS3Response.Message = responsebody;
            return oS3Response;           
        }


    }

    public interface IS3Service
    {
        Task<S3Response> NE_GetObjectFromAmazons3(string S3_KEY);
        Task<S3Response> NE_WriteContentObjectInAmazons3(string S3_KEY, string logs);
        Task<List<FileList>> ListingObjectsAsync(bool IsTextFileOnly);

        Task<S3Response> NE_ReadS3Data(string S3_KEY);



    }
}
