﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DemoIUI.Models;
using System.Net.Http;
using System.Dynamic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Data;
using Microsoft.AspNetCore.Mvc.Cors;
using Microsoft.AspNetCore.Http;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Net;
using System.IO;
using System.Runtime.Serialization.Formatters;
using static System.Net.Mime.MediaTypeNames;
using System.Drawing;

namespace DemoIUI.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Home()
        {

            return View();
        }


        public IActionResult Upload(){
            
            return View();
        }


        public IActionResult download()
        {
            Loggs oLoggs = new Loggs();
            oLoggs.IsTextFileOnly = false;           
            dynamic responses = Requestor.PostRequestors(Startup.ServicePath + "GellFileList", oLoggs);
            List<dynamic> st = JsonConvert.DeserializeObject<List<dynamic>>(responses.ToString());
            oLoggs.logList = st;
            return View(oLoggs);
        }

        [HttpPost]
        public IActionResult download(string filename, bool IsApplyKms)
        {
            Loggs oLoggs = new Loggs();
            oLoggs.S3Key = filename;
            dynamic responses;
            if (IsApplyKms == true)
            {
                responses = Requestor.PostRequestors(Startup.ServicePath + "DownloadFileFromS3", oLoggs);                    
            }
            else
            {
                responses = Requestor.PostRequestors(Startup.ServicePath + "DownloadFileNE", oLoggs);
            }

            dynamic st = JsonConvert.DeserializeObject<S3Response>(responses.ToString());

            byte[] filebody = st.response1;
            HttpContext.Session.Set("filebody", filebody);

            HttpContext.Session.SetString("filename", filename);
            return new JsonResult(responses);
        }
        public IActionResult ReadLog()
        {
            Loggs oLoggs = new Loggs();
            oLoggs.IsTextFileOnly = true;
            oLoggs.FileList=FileList(oLoggs);
            return View(oLoggs);
        }

        public IActionResult AddLog()
        {
            Loggs oLoggs = new Loggs();
            oLoggs.IsTextFileOnly = true;
            oLoggs.FileList = FileList(oLoggs);           
            return View(oLoggs);
        }

        public List<SelectListItem> FileList(Loggs oLoggs)
        {
            
            dynamic responses = Requestor.PostRequestors(Startup.ServicePath+"GellFileList", oLoggs);
            List<FileList> st = JsonConvert.DeserializeObject<List<FileList>>(responses.ToString());

            var filelist = (from product in st
                            select new SelectListItem()
                                {
                                    Text = product.FileName,
                                    Value = product.FileName.ToString(),
                                }).ToList();

            //filelist.Insert(0, new SelectListItem()
            //{
            //    Text = "----Select----",
            //    Value = string.Empty
            //});
            return filelist;
        }

        [HttpPost]
        public IActionResult ReadLog(Loggs Logs)
        {
            dynamic responses;
            Loggs oLoggs = new Loggs();
            if (Logs.logSource.ToUpper() == "DATABASE")
            {
                responses = Requestor.PostRequestors(Startup.ServicePath + "GetDLogs", Logs);
                List<dynamic> st = JsonConvert.DeserializeObject<List<dynamic>>(responses.ToString());
                oLoggs.logList = st;
            }
            else if (Logs.logSource.ToUpper() == "FILE")
            {
                Logs.S3Key = Logs.logFileName;
                S3Response st;
                if (Logs.IsApplyKms == false)
                {
                    responses = Requestor.PostRequestors(Startup.ServicePath + "ReadLogNE", Logs);
                    st = JsonConvert.DeserializeObject<S3Response>(responses.ToString());
                }
                else
                {
                    responses = Requestor.PostRequestors(Startup.ServicePath + "ReadS3TextFileData", Logs);
                    st = JsonConvert.DeserializeObject<S3Response>(responses.ToString());
                }
                oLoggs.logMessage = st.Message;
            }
            oLoggs.IsTextFileOnly = true;
            oLoggs.FileList = FileList(oLoggs);
            
            return View(oLoggs);
        }

        [HttpPost]
        public IActionResult Upload(Loggs oLoggs)
        {
            try
            {
                if (oLoggs.FileToUpload == null || oLoggs.FileToUpload.Length == 0)
                {
                   ViewData["Message"] = "Please select valid file. ";
                   View("Upload");
                }
                HttpClient client = new HttpClient();
              
                byte[] data;
                using (var br = new BinaryReader(oLoggs.FileToUpload.OpenReadStream()))
                {
                    data = br.ReadBytes((int)oLoggs.FileToUpload.OpenReadStream().Length);
                }
                ByteArrayContent bytes = new ByteArrayContent(data);
                MultipartFormDataContent multiContent = new MultipartFormDataContent();
                multiContent.Add(bytes, "FileToUpload", oLoggs.FileToUpload.FileName);
                var response =  client.PostAsync(Startup.ServicePath + "UploadFileToS3", multiContent);
                ViewData["Message"] = "File Uploaded Sucessfully.";
            }
            catch (Exception ex)
            {
                ViewData["Message"] = "File Uploaded failed.";
            }
            return View("Upload");
        }

        [HttpPost]
        public IActionResult AddLog(Loggs Logs)
        {
            dynamic responses;
            try
            {
                if (Logs.logSource.ToUpper() == "DATABASE")
                {
                    responses = Requestor.PostRequestors(Startup.ServicePath + "WriteDLogs", Logs);
                }
                else if (Logs.logSource.ToUpper() == "FILE")
                {
                    Logs.S3Key = Logs.logFileName;
                    if (Logs.IsApplyKms == true)
                    {
                        responses = Requestor.PostRequestors(Startup.ServicePath + "WriteTextIntoS3File", Logs);
                    }
                    else
                    {
                        responses = Requestor.PostRequestors(Startup.ServicePath + "WriteLogNE", Logs);
                    }

                }
                else if (Logs.logSource.ToUpper() == "BOTH")
                {
                    Logs.S3Key = Logs.logFileName;

                    responses = Requestor.PostRequestors(Startup.ServicePath + "WriteDLogs", Logs);
                    if (Logs.IsApplyKms == true)
                    {
                        responses = Requestor.PostRequestors(Startup.ServicePath + "WriteTextIntoS3File", Logs);
                    }
                    else
                    {
                        responses = Requestor.PostRequestors(Startup.ServicePath + "WriteLogNE", Logs);
                    }
                }
                ViewData["Message"] = "Add Record Sucessfully";
            }
            catch (Exception ex)
            {
                ViewData["Message"] = "Error during add record";
            }          

            Loggs oLoggs = new Loggs();
            oLoggs.IsTextFileOnly = true;
            oLoggs.FileList = FileList(oLoggs);
            return View(oLoggs);
        }

        public IActionResult DownloadFiles()
        {
            string filename = HttpContext.Session.GetString("filename");
            byte[] filebody = HttpContext.Session.Get("filebody");
            try
            {              
                return File(filebody, ContentType(filename), filename);
            }
            catch
            {
                return Error();
            }
            //Loggs oLoggs = new Loggs();
            //oLoggs.logPath = string.Format("{0}", Convert.ToBase64String(filebody));
            //return View(oLoggs);
        }


        public string ContentType(string filename)
        {
            string strContentType = "";
            string fileExtension = filename.Split(".")[1];
            switch (fileExtension)
            {
                case "txt":
                    strContentType = "text/plain";
                    break;
                case "jpeg":
                case "jpg":
                    strContentType = "image/jpeg";
                    break;
                case "pdf":
                      strContentType = "application/pdf";
                    break;
            }
            return strContentType;
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }

    public class FileList
    {
        public string FileName { get; set; }
        public int FileId { get; set; }
    }
    public class S3Response
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }

        public byte[] response1 { get; set; }

    }
}
