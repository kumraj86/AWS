﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Amazon.S3.Util;
using Amazon;
using Amazon.KeyManagementService;
using Amazon.S3.Encryption;
using Demo.Model;



namespace Demo.Services
{
    public class S3Service : IS3Service
    {
        private const string AWS_ACCESS_KEY = "AKIAIFO5AEGGOTWVPKNA";
        private const string AWS_SECRET_KEY = "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";
        private const string BUCKET_NAME = "demo03032021";
        // private const string S3_KEY = "Sravan_Test.txt";
        private const string KMSKeyID = "dce02bcf-0d42-4782-9c3d-48875b019480";

        public async Task<S3Response> NE_GetObjectFromAmazons3(string S3_KEY)
        {
            S3Response oS3Response = new S3Response();
            oS3Response.StatusCode = 0;
            string responsebody = "";
            try
            {
                AmazonS3Client _client = new AmazonS3Client(AWS_ACCESS_KEY, AWS_SECRET_KEY, Amazon.RegionEndpoint.USEast2);
                var request = new GetObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    Key = S3_KEY
                };
                using (var response = await _client.GetObjectAsync(request))
                using (var responseStream = response.ResponseStream)
                using (var reader = new StreamReader(responseStream))
                {
                    //responsebody = reader.ReadToEnd();
                    while (!reader.EndOfStream)
                    {
                        responsebody += reader.ReadLine();                        
                    }

                }
            }
            catch (Exception ex)
            {
                oS3Response.StatusCode = 1;
                responsebody = "Error during reading file";
            }
          
           
            oS3Response.Message = responsebody;
            return oS3Response;
        }

        public async Task<S3Response> NE_WriteContentObjectInAmazons3(string S3_KEY, string logs)
        {
            string responsebody = "";
            string readresponsebody = "";
            S3Response oS3Response = new S3Response();
            oS3Response.StatusCode = 0;
            AmazonS3Client _client = new AmazonS3Client(AWS_ACCESS_KEY, AWS_SECRET_KEY, Amazon.RegionEndpoint.USEast2);
            try
            {
                var request = new GetObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    Key = S3_KEY
                };
                using (var response = await _client.GetObjectAsync(request))
                using (var responseStream = response.ResponseStream)
                using (var reader = new StreamReader(responseStream))
                {
                    readresponsebody = reader.ReadToEnd();
                }

                var request1 = new PutObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    Key = S3_KEY,
                    ContentBody = readresponsebody + "<br>" + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss.fff tt", System.Globalization.CultureInfo.CurrentCulture) + " " + logs

                };
                // ContentBody = readresponsebody + "\n" + logs
                ////DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss.fff tt", System.Globalization.CultureInfo.CurrentCulture) + " " +
                await _client.PutObjectAsync(request1);
                responsebody = "Add record is succesfully";
            }
            catch (Exception ex)
            {
                oS3Response.StatusCode = 1;
                responsebody = "Error during writing in file";
            }
           
            oS3Response.Message = responsebody;
            return oS3Response;
        }

        public async Task<List<FileList>> ListingObjectsAsync()
        {
            string responsebody = "";
            List<FileList> fileList = new List<FileList>();
            AmazonS3Client _client = new AmazonS3Client(AWS_ACCESS_KEY, AWS_SECRET_KEY, Amazon.RegionEndpoint.USEast2);
            try
            {
                ListObjectsV2Request request = new ListObjectsV2Request
                {
                    BucketName = BUCKET_NAME,
                    MaxKeys = 10
                };
                ListObjectsV2Response response;
                do
                {
                    response = await _client.ListObjectsV2Async(request);
                    // Process the response.
                    int k = 1;
                    foreach (S3Object entry in response.S3Objects)
                    {
                        FileList objFileList = new FileList();
                        objFileList.FileId = k;
                        objFileList.FileName = entry.Key;
                        fileList.Add(objFileList);
                        k++;
                    }
                    request.ContinuationToken = response.NextContinuationToken;
                } while (response.IsTruncated);

            }
            catch (AmazonS3Exception amazonS3Exception)
            {
                Console.WriteLine("S3 error occurred. Exception: " + amazonS3Exception.ToString());
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.ToString());
                Console.ReadKey();
            }
            return fileList;
        }


        //public async Task<string> UploadFileToS3(string SrcFilePath)
        //{
        //    string responsebody = "";

        //    using (var kmsClient = new AmazonKeyManagementServiceClient(AWS_ACCESS_KEY, AWS_SECRET_KEY, Amazon.RegionEndpoint.USEast2))
        //    {
        //        var encryMaterials = new EncryptionMaterials(KMSKeyID);

        //        using (var s3Client = new AmazonS3EncryptionClient(Amazon.RegionEndpoint.USEast2, encryMaterials))
        //        {
        //            var putRequest = new PutObjectRequest
        //            {
        //                BucketName = BUCKET_NAME,
        //                Key = Path.GetFileName(SrcFilePath),
        //                FilePath = SrcFilePath  //@"C:\Users\Sravan\Desktop\AWS\Sravan_Test123.txt" //local file path
        //            };

        //            s3Client.PutObjectAsync(putRequest).GetAwaiter().GetResult();

        //            responsebody = "File Uploaded Successfully..!";
        //        }

        //    }
        //    return responsebody;
        //}


        //public async Task<string> DownloadFileFromS3(string _S3_KEY, string FolderPathToSave)
        //{
        //    string responsebody = "";
        //    using (var kmsClient = new AmazonKeyManagementServiceClient(AWS_ACCESS_KEY, AWS_SECRET_KEY, Amazon.RegionEndpoint.USEast2))
        //    {
        //        var encryMaterials = new EncryptionMaterials(KMSKeyID);

        //        using (var s3Client = new AmazonS3EncryptionClient(Amazon.RegionEndpoint.USEast2, encryMaterials))
        //        {
        //            TransferUtility fileTr = new TransferUtility(s3Client);
        //            fileTr.Download(FolderPathToSave.TrimEnd('\\') + "\\" + _S3_KEY, BUCKET_NAME, _S3_KEY);

        //            responsebody = "File Saved At : " + FolderPathToSave;
        //        }

        //    }

        //    return responsebody;
        //}

        //public async Task<S3Response> ReadS3TextFileData(string _S3_KEY)
        //{
        //    string responsebody = "";

        //    S3Response oS3Response = new S3Response();
        //    oS3Response.StatusCode = 0;
        //    try
        //    {
        //        using (var kmsClient = new AmazonKeyManagementServiceClient(AWS_ACCESS_KEY, AWS_SECRET_KEY, Amazon.RegionEndpoint.USEast2))
        //        {
        //            var encryMaterials = new EncryptionMaterials(KMSKeyID);

        //            using (var s3Client = new AmazonS3EncryptionClient(Amazon.RegionEndpoint.USEast2, encryMaterials))
        //            {

        //                var getRequest = new GetObjectRequest
        //                {
        //                    BucketName = BUCKET_NAME,
        //                    Key = _S3_KEY //"Sravan_Test.txt"
        //                };

        //                using (var response = await s3Client.GetObjectAsync(getRequest))
        //                using (var responseStream = response.ResponseStream)
        //                using (var reader = new StreamReader(responseStream))
        //                {
        //                    responsebody = reader.ReadToEnd();
        //                }
        //            }

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        oS3Response.StatusCode = 1;
        //        responsebody = "Error during reading from file";
        //    }

        //    oS3Response.Message = responsebody;
        //    return oS3Response;
        //}

        //public async Task<S3Response> WriteTextIntoS3File(string _S3_KEY, string Text)
        //{

        //    S3Response oS3Response = new S3Response();
        //    oS3Response.StatusCode = 0;
        //    string responsebody = "";
        //    string existedText = "";
        //    try
        //    {
        //        using (var kmsClient = new AmazonKeyManagementServiceClient(AWS_ACCESS_KEY, AWS_SECRET_KEY, Amazon.RegionEndpoint.USEast2))
        //        {
        //            var encryMaterials = new EncryptionMaterials(KMSKeyID);

        //            using (var s3Client = new AmazonS3EncryptionClient(Amazon.RegionEndpoint.USEast2, encryMaterials))
        //            {

        //                var getRequest = new GetObjectRequest
        //                {
        //                    BucketName = BUCKET_NAME,
        //                    Key = _S3_KEY
        //                };

        //                using (var response = await s3Client.GetObjectAsync(getRequest))
        //                using (var responseStream = response.ResponseStream)
        //                using (var reader = new StreamReader(responseStream))
        //                {
        //                    existedText = reader.ReadToEnd();

        //                    var putRequest = new PutObjectRequest
        //                    {
        //                        BucketName = BUCKET_NAME,
        //                        Key = _S3_KEY,
        //                        ContentBody = existedText + "\n" + Text
        //                    };

        //                    await s3Client.PutObjectAsync(putRequest);
        //                    //s3Client.PutObjectAsync(putRequest).GetAwaiter().GetResult();
        //                    responsebody = "Data Successfully Written..!";
        //                }
        //            }

        //        }
        //    }
        //    catch (Exception ex)
        //    {                
        //        oS3Response.StatusCode = 1;
        //        responsebody = "Error during writing in file";
        //    }

        //    oS3Response.Message = responsebody;
        //    return oS3Response;
        //}

    }

    public interface IS3Service
    {
        Task<S3Response> NE_GetObjectFromAmazons3(string S3_KEY);
        Task<S3Response> NE_WriteContentObjectInAmazons3(string S3_KEY, string logs);
        Task<List<FileList>> ListingObjectsAsync();

        //Task<string> UploadFileToS3(string SrcFilePath);
        //Task<string> DownloadFileFromS3(string S3Key, string FolderPathToSave);
        //Task<S3Response> ReadS3TextFileData(string S3Key);
        //Task<S3Response> WriteTextIntoS3File(string S3Key, string Text);
    }
}
