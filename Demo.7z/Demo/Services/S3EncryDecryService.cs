﻿using Amazon;
using Amazon.KeyManagementService;
using Amazon.S3.Encryption;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using Demo.Model;

namespace Demo.Services
{
    public class S3EncryDecryService : IS3EncryDecryService
    {
        private AmazonKeyManagementServiceClient client;
        //private static readonly ILog _logger = LogManager.GetLogger(typeof(KMSHelper));
        private readonly string accessKey, secretKey, KMSKeyID, BUCKET_NAME; /*serviceUrl -> region*/
        private readonly RegionEndpoint region;

        public S3EncryDecryService() //string accessKey, string secretKey, RegionEndpoint region) //string serviceUrl)
        {
            accessKey = "AKIAIFO5AEGGOTWVPKNA";
            secretKey = "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";
            region = RegionEndpoint.USEast2;
            KMSKeyID = "dce02bcf-0d42-4782-9c3d-48875b019480";
            //S3_KEY = "Sravan_Test.txt";  //"TestImage.jpg";//
            BUCKET_NAME = "demo03032021";
        }

        /*
         Example Method Calling :
        string mssg = await S3ED.UploadFileToS3(@"C:\Users\Sravan\Desktop\AWS\TestImg.jpg");
         */
        public async Task<S3Response> UploadFileToS3(string SrcFilePath)
        {
            string responsebody = "";
            S3Response oS3Response = new S3Response();
            oS3Response.StatusCode = 0;
            try
            {

                using (var kmsClient = new AmazonKeyManagementServiceClient(accessKey, secretKey, region))
                {
                    var encryMaterials = new EncryptionMaterials(KMSKeyID);

                    using (var s3Client = new AmazonS3EncryptionClient(region, encryMaterials))
                    {
                        var putRequest = new PutObjectRequest
                        {
                            BucketName = BUCKET_NAME,
                            Key = Path.GetFileName(SrcFilePath),
                            FilePath = SrcFilePath  
                        };

                        s3Client.PutObjectAsync(putRequest).GetAwaiter().GetResult();

                        responsebody = "File Uploaded Successfully..!";
                    }

                }
            }
            catch (Exception ex)
            {
                oS3Response.StatusCode =1;
                responsebody = "Error during UploadFileToS3 file in S3";
            }

            
            oS3Response.Message = responsebody;
            return oS3Response;
        }

        /*
         Example Method Calling :
        string mssg = await S3ED.DownloadFileFromS3("TestImage.jpg", @"C:\Users\Sravan\Desktop\AWS");
         */
        public async Task<S3Response> DownloadFileFromS3(string _S3_KEY, string FolderPathToSave)
        {
            string responsebody = "";
            S3Response oS3Response = new S3Response();
            oS3Response.StatusCode = 0;
            try
            {
                using (var kmsClient = new AmazonKeyManagementServiceClient(accessKey, secretKey, region))
                {
                    var encryMaterials = new EncryptionMaterials(KMSKeyID);

                    using (var s3Client = new AmazonS3EncryptionClient(region, encryMaterials))
                    {
                        TransferUtility fileTr = new TransferUtility(s3Client);
                        fileTr.Download(FolderPathToSave.TrimEnd('\\') + "\\" + _S3_KEY, BUCKET_NAME, _S3_KEY);

                        responsebody = "File Saved At : " + FolderPathToSave;
                    }

                }
            }
            catch (Exception ex)
            {
                oS3Response.StatusCode = 1;
                responsebody = "Error during downloding file from S3";
            }

          
            oS3Response.Message = responsebody;
            return oS3Response;


        }


        /*
         Example Method Calling :
        string mssg = await S3ED.ReadS3TextFileData("Sravan_Test.txt");
         */
        public async Task<S3Response> ReadS3TextFileData(string _S3_KEY)
        {
            string responsebody = "";
            S3Response oS3Response = new S3Response();
            oS3Response.StatusCode = 0;
            try
            {
                using (var kmsClient = new AmazonKeyManagementServiceClient(accessKey, secretKey, region))
                {
                    var encryMaterials = new EncryptionMaterials(KMSKeyID);

                    using (var s3Client = new AmazonS3EncryptionClient(region, encryMaterials))
                    {

                        var getRequest = new GetObjectRequest
                        {
                            BucketName = BUCKET_NAME,
                            Key = _S3_KEY //"Sravan_Test.txt"
                        };

                        using (var response = await s3Client.GetObjectAsync(getRequest))
                        using (var responseStream = response.ResponseStream)
                        using (var reader = new StreamReader(responseStream))
                        {
                            responsebody = reader.ReadToEnd();
                        }
                    }

                }

            }
            catch (Exception ex)
            {
                oS3Response.StatusCode = 1;
                responsebody = "Error during reading from file";
            }

        
            oS3Response.Message = responsebody;
            return oS3Response;
        }

        /*
         Example Method Calling :
        string mssg = await S3ED.WriteTextIntoS3File("Sravan_Test.txt","New Entry..!!");
         */
        public async Task<S3Response> WriteTextIntoS3File(string _S3_KEY, string Text)
        {
            string responsebody = "";
            string existedText = "";
            S3Response oS3Response = new S3Response();
            oS3Response.StatusCode = 0;
            try
            {
                using (var kmsClient = new AmazonKeyManagementServiceClient(accessKey, secretKey, region))
                {
                    var encryMaterials = new EncryptionMaterials(KMSKeyID);

                    using (var s3Client = new AmazonS3EncryptionClient(region, encryMaterials))
                    {

                        var getRequest = new GetObjectRequest
                        {
                            BucketName = BUCKET_NAME,
                            Key = _S3_KEY
                        };

                        using (var response = await s3Client.GetObjectAsync(getRequest))
                        using (var responseStream = response.ResponseStream)
                        using (var reader = new StreamReader(responseStream))
                        {
                            existedText = reader.ReadToEnd();

                            var putRequest = new PutObjectRequest
                            {
                                BucketName = BUCKET_NAME,
                                Key = _S3_KEY,
                                ContentBody = existedText + "\n" + Text
                            };

                            await s3Client.PutObjectAsync(putRequest);
                            //s3Client.PutObjectAsync(putRequest).GetAwaiter().GetResult();
                            responsebody = "Data Successfully Written..!";
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                oS3Response.StatusCode = 1;
                responsebody = "Error during writing in file";
            }

           
           
            oS3Response.Message = responsebody;
            return oS3Response;
        }


    }



    public interface IS3EncryDecryService
    {
        Task<S3Response> UploadFileToS3(string SrcFilePath);
        Task<S3Response> DownloadFileFromS3(string S3Key, string FolderPathToSave);
        Task<S3Response> ReadS3TextFileData(string S3Key);
        Task<S3Response> WriteTextIntoS3File(string S3Key, string Text);
    }
}
