﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Amazon.S3.Util;
using Demo.Services;
using Npgsql;
using NpgsqlTypes;
using System.Data;
using Demo.Model;
using Demo.Services;


namespace Demo.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class SampleController : ControllerBase
    {
        private readonly IS3Service _service;
        public SampleController(IS3Service service)
        {
            _service = service;
        }
        
      

        [HttpGet]
        public ActionResult<string> GetMessage()
        {
            try
            {
                return "Hello World !";
            }
            catch (Exception ex)
            {
                return "Error in GetMessage method !";
            }
        }


        [HttpPost]
        public async Task<ActionResult> WriteLogNE(Loggs oLoggs)
        {
            S3Response mssg = await _service.NE_WriteContentObjectInAmazons3(oLoggs.S3Key,oLoggs.logMessage);
            return Ok(mssg); 

        }

        [HttpPost]
        public async Task<ActionResult> ReadLogNE(Loggs oLoggs)
        {
            S3Response mssg = await _service.NE_GetObjectFromAmazons3(oLoggs.S3Key);
           return Ok(mssg);
        }


        [HttpGet]
        public async Task<ActionResult> GellFileList()
        {
            List<FileList> flist = await _service.ListingObjectsAsync();
            return Ok(flist);
        }

        [HttpPost]
        public ActionResult GetDLogs()
        {
            DataTable dt = new DataTable();
            using (NpgsqlConnection connection = new NpgsqlConnection())
            {
                connection.ConnectionString = "Server=localhost;Port=5432;User Id=postgres;Password=admin@123;Database=Logger;";
                connection.Open();

                NpgsqlTransaction tran = connection.BeginTransaction();
                NpgsqlCommand cmd = new NpgsqlCommand("show_log");               
                cmd.Connection = connection;                
                cmd.CommandType = CommandType.StoredProcedure;          

                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);              
                da.Fill(dt);
                cmd.Dispose();
                tran.Commit();  
                connection.Close();                
            }           
            return Ok(dt);
        }


        [HttpPost]
        public ActionResult WriteDLogs(Loggs oLoggs)
        {
            DataTable dt = new DataTable();
            using (NpgsqlConnection connection = new NpgsqlConnection())
            {
                connection.ConnectionString = "Server=localhost;Port=5432;User Id=postgres;Password=admin@123;Database=Logger;";
                connection.Open();

                NpgsqlTransaction tran = connection.BeginTransaction();
                NpgsqlCommand cmd = new NpgsqlCommand("add_log");               
                cmd.Parameters.Add("logmessage", NpgsqlDbType.Varchar).Value = oLoggs.logMessage;
                cmd.Connection = connection;
                cmd.CommandType = CommandType.StoredProcedure;

                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                da.Fill(dt);
                cmd.Dispose();
                tran.Commit();
                connection.Close();
            }
            return Ok(dt);
        }


        [HttpPost]
        [Consumes("multipart/form-data","application/json")]
        public async Task<ActionResult> UploadFileToS3([FromForm]Loggs oLoggs)
        {
            S3EncryDecryService oS3EncryDecryService = new S3EncryDecryService();
            var filePath = Path.GetTempFileName();
            string strPath = Path.GetFullPath("~/BookingFiles").Replace("~\\", "") +"\\"+ oLoggs.FileToUpload.FileName;
            using (var stream = new FileStream(strPath, FileMode.Create))
            {
                await oLoggs.FileToUpload.CopyToAsync(stream);
            }
            S3Response mssg = await oS3EncryDecryService.UploadFileToS3(strPath);
            return Ok(mssg);
        }


        [HttpPost]
        public async Task<ActionResult> DownloadFileFromS3(Loggs oLoggs)
        {
            S3EncryDecryService oS3EncryDecryService = new S3EncryDecryService();
            S3Response mssg = await oS3EncryDecryService.DownloadFileFromS3(oLoggs.S3Key,oLoggs.logPath);
            return Ok(mssg);
        }

        //[HttpPost]
        public async Task<ActionResult> ReadS3TextFileData()
        {
            S3EncryDecryService oS3EncryDecryService = new S3EncryDecryService();
            S3Response mssg = await oS3EncryDecryService.ReadS3TextFileData("Sravan_Test.txt");
            return Ok(mssg);
        }

        //[HttpPost]
        public async Task<ActionResult> WriteTextIntoS3File(Loggs oLoggs)
        {
            S3EncryDecryService oS3EncryDecryService = new S3EncryDecryService();
            S3Response mssg = await oS3EncryDecryService.WriteTextIntoS3File(oLoggs.S3Key,oLoggs.logMessage);
            return Ok(mssg);
        }

    }
}
       