﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DemoIUI.Models;
using System.Net.Http;
using System.Dynamic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Data;
using Microsoft.AspNetCore.Mvc.Cors;
using Microsoft.AspNetCore.Http;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Net;
using System.IO;

namespace DemoIUI.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Upload(){
            
            return View();
        }


        public IActionResult download()
        {
            Loggs oLoggs = new Loggs();
            dynamic responses = Requestor.GetRequestors(Startup.ServicePath + "GellFileList");
            List<dynamic> st = JsonConvert.DeserializeObject<List<dynamic>>(responses.ToString());
            oLoggs.logList = st;
            return View(oLoggs);
        }

        [HttpPost]
        public IActionResult download(string filename)
        {
            Loggs oLoggs = new Loggs();
            oLoggs.S3Key = filename;
            dynamic responses = Requestor.PostRequestors(Startup.ServicePath + "DownloadFileFromS3", oLoggs);          
            return new JsonResult(responses);
        }
        public IActionResult ReadLog()
        {
            Loggs oLoggs = new Loggs();
            oLoggs.FileList=FileList();
            return View(oLoggs);
        }

        public IActionResult AddLog()
        {
            Loggs oLoggs = new Loggs();
            oLoggs.FileList = FileList();           
            return View(oLoggs);
        }

        public List<SelectListItem> FileList()
        {
            
            dynamic responses = Requestor.GetRequestors(Startup.ServicePath+"GellFileList");
            List<FileList> st = JsonConvert.DeserializeObject<List<FileList>>(responses.ToString());

            var filelist = (from product in st
                            select new SelectListItem()
                                {
                                    Text = product.FileName,
                                    Value = product.FileName.ToString(),
                                }).ToList();

            //filelist.Insert(0, new SelectListItem()
            //{
            //    Text = "----Select----",
            //    Value = string.Empty
            //});
            return filelist;
        }

        [HttpPost]
        public IActionResult ReadLog(Loggs Logs)
        {
            dynamic responses;
            Loggs oLoggs = new Loggs();
            if (Logs.logSource.ToUpper() == "DATABASE")
            {
                responses = Requestor.PostRequestors(Startup.ServicePath + "GetDLogs", Logs);
                List<dynamic> st = JsonConvert.DeserializeObject<List<dynamic>>(responses.ToString());
                oLoggs.logList = st;
            }
            else if (Logs.logSource.ToUpper() == "FILE")
            {
                Logs.S3Key = Logs.logFileName;
                S3Response st;
                if (Logs.IsApplyKms == false)
                {
                    responses = Requestor.PostRequestors(Startup.ServicePath + "ReadLogNE", Logs);
                    st = JsonConvert.DeserializeObject<S3Response>(responses.ToString());
                }
                else
                {
                    responses = Requestor.PostRequestors(Startup.ServicePath + "ReadS3TextFileData", Logs);
                    st = JsonConvert.DeserializeObject<S3Response>(responses.ToString());
                }
                oLoggs.logMessage = st.Message;
            }   
            oLoggs.FileList = FileList();
            return View(oLoggs);
        }

        [HttpPost]
        public IActionResult Upload(Loggs oLoggs)
        {
            try
            {
                if (oLoggs.FileToUpload == null || oLoggs.FileToUpload.Length == 0)
                    return Content("file not selected");
                HttpClient client = new HttpClient();
              
                byte[] data;
                using (var br = new BinaryReader(oLoggs.FileToUpload.OpenReadStream()))
                {
                    data = br.ReadBytes((int)oLoggs.FileToUpload.OpenReadStream().Length);
                }
                ByteArrayContent bytes = new ByteArrayContent(data);
                MultipartFormDataContent multiContent = new MultipartFormDataContent();
                multiContent.Add(bytes, "FileToUpload", oLoggs.FileToUpload.FileName);
                var response =  client.PostAsync(Startup.ServicePath + "UploadFileToS3", multiContent);
            }
            catch (Exception ex)
            {
            }
            return RedirectToAction("Upload");
        }

        [HttpPost]
        public IActionResult AddLog(Loggs Logs)
        {
            dynamic responses;
            try
            {
                if (Logs.logSource.ToUpper() == "DATABASE")
                {
                    responses = Requestor.PostRequestors(Startup.ServicePath + "WriteDLogs", Logs);
                }
                else if (Logs.logSource.ToUpper() == "FILE")
                {
                    Logs.S3Key = Logs.logFileName;
                    if (Logs.IsApplyKms == true)
                    {
                        responses = Requestor.PostRequestors(Startup.ServicePath + "WriteTextIntoS3File", Logs);
                    }
                    else
                    {
                        responses = Requestor.PostRequestors(Startup.ServicePath + "WriteLogNE", Logs);
                    }

                }
                else if (Logs.logSource.ToUpper() == "BOTH")
                {
                    Logs.S3Key = Logs.logFileName;

                    responses = Requestor.PostRequestors(Startup.ServicePath + "WriteDLogs", Logs);
                    if (Logs.IsApplyKms == true)
                    {
                        responses = Requestor.PostRequestors(Startup.ServicePath + "WriteTextIntoS3File", Logs);
                    }
                    else
                    {
                        responses = Requestor.PostRequestors(Startup.ServicePath + "WriteLogNE", Logs);
                    }
                }
                ViewData["Message"] = "Add Record Sucessfully";
            }
            catch (Exception ex)
            {
                ViewData["Message"] = "Error during add record";
            }          

            Loggs oLoggs = new Loggs();
            oLoggs.FileList = FileList();
            return View(oLoggs);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }

    public class FileList
    {
        public string FileName { get; set; }
        public int FileId { get; set; }
    }
    public class S3Response
    {
        public HttpStatusCode Status { get; set; }
        public string Message { get; set; }

    }
}
