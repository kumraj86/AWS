﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoIUI.Models
{
    public class Loggs
    {
        public string logSource { get; set; }
        public List<SelectListItem> FileList { get; set; }
        public string logMessage { get; set; }
        public string logFileName { get; set; }   
        

        public string logPath { get; set; }

        public string S3Key { get; set; }

        public List<dynamic> logList { get; set; }

        public bool IsApplyKms { get; set; }

        public IFormFile FileToUpload { get; set; }

        public IFormFile file { get; set; }



    }
}
