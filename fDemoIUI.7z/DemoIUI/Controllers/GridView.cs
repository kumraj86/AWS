﻿namespace DemoIUI.Controllers
{
    internal class GridView
    {
        public GridView()
        {
        }
    }
}